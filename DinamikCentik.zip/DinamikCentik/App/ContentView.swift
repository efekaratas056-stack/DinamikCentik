//
//  ContentView.swift
//  Ana uygulama hedefine eklenir.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var manager = NotchActivityManager()
    @State private var progressTimer: Timer?

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Bir duruma dokun, sonra kilit ekranına git veya cihazı uyut — kartı orada göreceksin.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)

                Button {
                    manager.start(mode: .music, title: "Bir Başkadır", subtitle: "Feridun Düzağaç")
                    startFakeProgress()
                } label: {
                    Label("Müzik başlat", systemImage: "music.note")
                }
                .buttonStyle(.borderedProminent)

                Button {
                    manager.start(mode: .call, title: "Anne", subtitle: "arıyor…")
                } label: {
                    Label("Arama simüle et", systemImage: "phone.fill")
                }
                .buttonStyle(.bordered)

                Button {
                    manager.start(mode: .timer, title: "Zamanlayıcı", subtitle: "çay demleniyor")
                    startFakeProgress()
                } label: {
                    Label("Zamanlayıcı başlat", systemImage: "timer")
                }
                .buttonStyle(.bordered)

                Button {
                    manager.start(mode: .faceID, title: "Face ID", subtitle: "kilit açıldı")
                } label: {
                    Label("Face ID göster", systemImage: "faceid")
                }
                .buttonStyle(.bordered)

                Button(role: .destructive) {
                    progressTimer?.invalidate()
                    Task { await manager.end() }
                } label: {
                    Label("Bitir", systemImage: "xmark.circle")
                }
                .padding(.top, 8)
            }
            .padding()
            .navigationTitle("Dinamik Çentik")
        }
    }

    /// Sadece demo amaçlı: ilerlemeyi 0'dan 1'e sahte olarak artırır.
    private func startFakeProgress() {
        var value = 0.0
        progressTimer?.invalidate()
        progressTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            value += 0.05
            if value >= 1.0 {
                value = 0
            }
            Task { await manager.update(progress: value) }
        }
    }
}

#Preview {
    ContentView()
}
