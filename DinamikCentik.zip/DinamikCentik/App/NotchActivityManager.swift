//
//  NotchActivityManager.swift
//  Ana uygulama (App) hedefine eklenir.
//

import ActivityKit
import Foundation

@MainActor
final class NotchActivityManager: ObservableObject {

    @Published private(set) var currentActivity: Activity<DinamikCentikAttributes>?

    /// Yeni bir Live Activity başlatır (ör. müzik çalmaya başlayınca).
    func start(mode: NotchMode, title: String, subtitle: String) {
        // Kullanıcı, ayarlarda Live Activities'i kapatmış olabilir; bunu kontrol etmek şart.
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            print("Live Activities kapalı — Ayarlar > [Uygulama Adı] > Live Activities'ten açılmalı.")
            return
        }

        // Zaten açık bir aktivite varsa önce onu kapat.
        Task { await end() }

        let attributes = DinamikCentikAttributes(appName: "Dinamik Çentik")
        let state = DinamikCentikAttributes.ContentState(
            mode: mode, title: title, subtitle: subtitle, progress: 0.0
        )

        do {
            let activity = try Activity.request(
                attributes: attributes,
                content: .init(state: state, staleDate: nil),
                pushType: nil // Uzaktan (sunucudan) güncelleme istersen burada .token kullanılır
            )
            currentActivity = activity
        } catch {
            print("Live Activity başlatılamadı: \(error)")
        }
    }

    /// Var olan aktivitenin içeriğini günceller (ör. şarkı ilerlemesi, kalan süre).
    func update(title: String? = nil, subtitle: String? = nil, progress: Double? = nil) async {
        guard let activity = currentActivity else { return }
        var state = activity.content.state
        if let title { state.title = title }
        if let subtitle { state.subtitle = subtitle }
        if let progress { state.progress = progress }
        await activity.update(.init(state: state, staleDate: nil))
    }

    /// Aktiviteyi kapatır (ör. müzik durunca, arama bitince).
    func end() async {
        guard let activity = currentActivity else { return }
        await activity.end(
            ActivityContent(state: activity.content.state, staleDate: nil),
            dismissalPolicy: .immediate
        )
        currentActivity = nil
    }
}
