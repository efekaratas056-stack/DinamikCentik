//
//  DinamikCentikAttributes.swift
//  Bu dosyayı HEM ana app hedefine HEM DE widget extension hedefine ekle.
//  (Xcode'da dosyayı seçip sağdaki "Target Membership" kutusunda iki kutucuğu da işaretle.)
//

import ActivityKit
import Foundation

enum NotchMode: String, Codable, Hashable {
    case music
    case call
    case timer
    case faceID
}

struct DinamikCentikAttributes: ActivityAttributes {

    // Aktivite boyunca DEĞİŞMEYEN veriler
    public var appName: String

    // Aktivite süresince GÜNCELLENEBİLEN veriler
    public struct ContentState: Codable, Hashable {
        var mode: NotchMode
        var title: String
        var subtitle: String
        var progress: Double   // 0.0 - 1.0 arası, müzik/zamanlayıcı ilerlemesi için
    }
}
