//
//  DinamikCentikLiveActivity.swift
//  Bu dosya SADECE Widget Extension hedefine eklenir.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct DinamikCentikLiveActivity: Widget {

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: DinamikCentikAttributes.self) { context in

            // ---- KİLİT EKRANI / BANNER GÖRÜNÜMÜ ----
            // iPhone 13 gibi çentikli (Dynamic Island'sız) cihazlarda
            // kullanıcı bunu kilit ekranında ve bildirim merkezinde görür.
            LockScreenNotchView(state: context.state, appName: context.attributes.appName)
                .activityBackgroundTint(Color.black)
                .activitySystemActionForegroundColor(Color.white)

        } dynamicIsland: { context in
            // ---- DYNAMIC ISLAND GÖRÜNÜMÜ ----
            // Bu blok sadece Dynamic Island'lı cihazlarda (14 Pro ve sonrası) çalışır.
            // iPhone 13'te bu kod çalışmaz ama derlenmesi için gerekli.
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    iconView(for: context.state.mode)
                        .font(.title2)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.subtitle)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.state.title)
                        .font(.headline)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    ProgressView(value: context.state.progress)
                        .tint(.green)
                }
            } compactLeading: {
                iconView(for: context.state.mode)
            } compactTrailing: {
                Text(context.state.subtitle)
                    .font(.caption2)
            } minimal: {
                iconView(for: context.state.mode)
            }
        }
    }

    @ViewBuilder
    private func iconView(for mode: NotchMode) -> some View {
        switch mode {
        case .music:  Image(systemName: "music.note")
        case .call:   Image(systemName: "phone.fill")
        case .timer:  Image(systemName: "timer")
        case .faceID: Image(systemName: "faceid")
        }
    }
}

// ---- Kilit ekranında görünecek asıl tasarım ----
// iPhone 13'ün çentik siluetini andıran, koyu, yuvarlak köşeli bir kart.
struct LockScreenNotchView: View {
    let state: DinamikCentikAttributes.ContentState
    let appName: String

    var body: some View {
        HStack(spacing: 12) {
            iconBadge

            VStack(alignment: .leading, spacing: 2) {
                Text(state.title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                Text(state.subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }

            Spacer()

            if state.mode == .call {
                HStack(spacing: 10) {
                    Circle().fill(Color.red).frame(width: 30, height: 30)
                        .overlay(Image(systemName: "phone.down.fill").foregroundColor(.white).font(.system(size: 12)))
                    Circle().fill(Color.green).frame(width: 30, height: 30)
                        .overlay(Image(systemName: "phone.fill").foregroundColor(.white).font(.system(size: 12)))
                }
            } else {
                ProgressView(value: state.progress)
                    .frame(width: 50)
                    .tint(.green)
            }
        }
        .padding(14)
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 24))
    }

    private var iconBadge: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(LinearGradient(colors: [.orange, .red], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 34, height: 34)
            switch state.mode {
            case .music:  Image(systemName: "music.note").foregroundColor(.white)
            case .call:   Image(systemName: "phone.fill").foregroundColor(.white)
            case .timer:  Image(systemName: "timer").foregroundColor(.white)
            case .faceID: Image(systemName: "faceid").foregroundColor(.white)
            }
        }
    }
}
