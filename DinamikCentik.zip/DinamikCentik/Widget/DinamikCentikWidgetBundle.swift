//
//  DinamikCentikWidgetBundle.swift
//  Widget Extension hedefine eklenir.
//  Xcode "Widget Extension" şablonu eklediğinde otomatik bir @main dosyası oluşturur;
//  onu bununla değiştir (veya içeriğini bununla birleştir).
//

import WidgetKit
import SwiftUI

@main
struct DinamikCentikWidgetBundle: WidgetBundle {
    var body: some Widget {
        DinamikCentikLiveActivity()
    }
}
