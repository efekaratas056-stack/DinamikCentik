# Dinamik Çentik — Xcode Kurulumu

Bu, telefonuna App Store'dan indirilecek bir şey değil; kendi Apple ID'inle
Xcode üzerinden derleyip kendi iPhone'una yükleyeceğin bir mini proje.

## Gereksinimler
- Mac + Xcode (App Store'dan ücretsiz)
- iPhone 13, iOS 16.1 veya üzeri
- Ücretsiz bir Apple ID yeterli (Developer Program'a üye olmana **gerek yok**,
  sadece kendi cihazına 7 günde bir yeniden imzalaman gerekir. Ücretli üyelik
  bu sınırı kaldırır ama ilk denemek için şart değil.)

## Adımlar

1. **Yeni proje aç**
   Xcode → File → New → Project → iOS → App
   Ürün adı: `DinamikCentik`, Arayüz: SwiftUI, Dil: Swift.

2. **Widget Extension ekle**
   File → New → Target → Widget Extension
   Adı: `DinamikCentikWidget`
   "Include Live Activity" kutusunu **işaretle** (Xcode 15+ bunu otomatik sorar).

3. **Dosyaları yerleştir**
   - `DinamikCentikAttributes.swift` → projeye sürükle, **her iki target'ı da** işaretle
     (App + Widget Extension) — sağ panelde "Target Membership".
   - `App/ContentView.swift` ve `App/NotchActivityManager.swift` → sadece **App** target'ına.
   - `Widget/DinamikCentikLiveActivity.swift` ve `Widget/DinamikCentikWidgetBundle.swift`
     → sadece **Widget Extension** target'ına. Xcode'un otomatik oluşturduğu
     eski `@main` widget dosyasını sil, çakışmasın.

4. **Info.plist'e izin ekle (App target'ının Info.plist'i)**
   Key: `NSSupportsLiveActivities`
   Type: Boolean
   Value: `YES`

5. **İmzalama**
   Proje ayarları → Signing & Capabilities → Team kısmına kendi Apple ID'ini seç.
   "Automatically manage signing" işaretli kalsın.

6. **Cihaza yükle**
   iPhone'unu kabloyla bağla, Xcode'da cihazını hedef olarak seç, ▶ Run.
   İlk seferde iPhone'da Ayarlar → Genel → VPN ve Cihaz Yönetimi'nden
   geliştirici sertifikana güvenmen gerekebilir.

7. **Dene**
   Uygulamayı aç, "Müzik başlat" gibi bir butona bas, sonra ekranı kapat
   (yan tuşa bas) veya kilit ekranına dön. Kartı orada göreceksin.
   iPhone 13'te bu kart **kilit ekranında** çıkar; Dynamic Island olmadığı
   için üst çentikte değil.

## Bilmen gereken sınırlamalar
- Bir Live Activity **en fazla 8 saat** açık kalabilir, sonra sistem otomatik kapatır.
- Uygulamanın arka planda "gerçek" müzik/zamanlayıcı çalıştırması ayrı bir iştir
  (AVAudioSession, arka plan modları vb.) — bu proje sadece Live Activity'nin
  kendisini gösteriyor, gerçek müzik çalmıyor.
- 7 günlük ücretsiz imzada, süre dolunca Xcode'dan tekrar Run demen yeterli.
